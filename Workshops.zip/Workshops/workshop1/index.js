class Counter {
    count = 0;

    handleIncrement = () => {
        this.count++;
        this.render();
    }

    handleDecrement = () => {
        this.count--;
        this.render();
    }

    showActionButton(action) {
        const actionHash = {
            Increment: this.handleIncrement,
            Decrement: this.handleDecrement
        };

        const button = document.createElement('button');
        button.textContent = action;
        button.onclick = actionHash[action];
        
        return button;
    }

    showCounter() {
        const counterValueElement = document.createElement('p');
        counterValueElement.innerHTML = this.count;
        return counterValueElement;
    }

    render() {
        const app = document.getElementById('app');
        app.innerHTML = "";

        const containerElements = [
            this.showCounter(),
            this.showActionButton('Increment'),
            this.showActionButton('Decrement'),
        ];

        /* const fragment = document.createDocumentFragment();
        containerElements.forEach(element => {
            fragment.append(element);
        });

        app.appendChild(fragment); */
        const container = document.createElement('div');
        containerElements.forEach(element => {
            container.appendChild(element);
        });

        app.appendChild(container);
    }
}
new Counter().render();
