
import React from 'react'
import './App.css'

class Counter extends React.Component{
  state = {count: 0};

  handleIncrement = () => {
    this.setState({count: this.state.count + 1});
  }

  handleDecrement = () => {
    this.setState({count: this.state.count - 1});
  }

  render() {
    return React.createElement("div", null, 
      React.createElement("p", null, this.state.count), 
      React.createElement("button", {onClick: this.handleIncrement}, "Increment"), 
      React.createElement("button", {onClick: this.handleDecrement}, "Decrement")
    );
  }
}


function App() {
  return (
    <Counter />
  )
}

export default App
